Place your pizza_sales_dashboard.pbix file here before pushing to GitHub.
Note: GitHub has a 100MB file size limit per file (25MB via web upload) — if your
.pbix exceeds that, consider Git LFS: https://git-lfs.github.com
